
AngularJS Material library provides UI elements based on the Goggle’s Material design guidelines.


Steps to install Angular Material Library
========================================

We can install library in 3 ways 
  a) bower
  b) npm
  c) google CDN

* Open terminal and create the directory as "MaterialDemo"

* Type bower install angular-material.

 
Ref
===
https://material.angularjs.org
https://github.com/angular/bower-material
https://github.com/saan1984
http://www.tutorialsavvy.com/2015/04/building-a-sample-profile-using-angular-material.html/

